package com.s18.themestudio.core;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

/**
 * Plain-Java checks used by JUnit and runnable without any test library.
 * The archives below are built on the fly only to exercise the engine; they are test inputs,
 * never shown in the app.
 */
public final class SelfTest {
    private static final byte[] PNG = {(byte) 0x89, 'P', 'N', 'G', 0x0D, 0x0A, 0x1A, 0x0A, 0, 0, 0, 0};

    static void check(boolean ok, String msg) { if (!ok) throw new AssertionError(msg); }

    static byte[] zip(Object... pairs) throws IOException {
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        ZipOutputStream z = new ZipOutputStream(bo);
        for (int i = 0; i < pairs.length; i += 2) {
            String name = (String) pairs[i];
            byte[] data = (byte[]) pairs[i + 1];
            z.putNextEntry(new ZipEntry(name));
            if (data != null) z.write(data);
            z.closeEntry();
        }
        z.close();
        return bo.toByteArray();
    }

    public static void run(File tmpDir) throws Exception {
        // sniffer
        check(Sniffer.sniff(PNG, PNG.length) == NodeKind.PNG, "png");
        check(Sniffer.sniff(new byte[]{'P', 'K', 3, 4}, 4) == NodeKind.ZIP, "zip");
        check(Sniffer.sniff(new byte[]{3, 0, 8, 0, 1}, 5) == NodeKind.AXML, "axml");
        check(Sniffer.sniff(" <a/>".getBytes(StandardCharsets.UTF_8), 5) == NodeKind.XML, "xml");
        check(Sniffer.sniff(new byte[0], 0) == NodeKind.EMPTY, "empty");

        // nested archive: outer -> inner zip -> files; png content named .webp; empty .webp; PNG named .xml
        byte[] inner = zip("night/theme.xml", "<resources/>".getBytes(StandardCharsets.UTF_8),
                "night/res/a.png", PNG, "night/res/b.png", PNG,
                "night/res/fake.webp", PNG, "night/res/empty.webp", new byte[0],
                "night/res/img.xml", PNG);
        byte[] desc = "<?xml version=\"1.0\"?><HwTheme><title>t&#55357;&#56740;x</title><version>3</version></HwTheme>"
                .getBytes(StandardCharsets.UTF_8);
        byte[] outer = zip("description.xml", desc, "wallpaper/", null, "wallpaper/w.jpg",
                new byte[]{(byte) 0xFF, (byte) 0xD8, (byte) 0xFF, (byte) 0xE0, 0, 0}, "pkg.one", inner);
        File f = new File(tmpDir, "t.hnt");
        FileOutputStream fo = new FileOutputStream(f);
        fo.write(outer);
        fo.close();

        ThemeArchive a = ThemeArchive.open(f, new File(tmpDir, "cache"));
        ThemeReport r = a.getReport();
        check(r.archiveCount == 1 && r.maxDepth == 1, "nested count");
        check(a.get("pkg.one").isArchive && a.get("pkg.one").isContainer(), "archive as folder");
        check(a.get("pkg.one/night").isDirectory, "synthesized folder");
        check(a.children("pkg.one/night/res").size() == 5, "children count " + a.children("pkg.one/night/res").size());
        check(r.ninePatchCount == 0, "nine patch");
        check(r.emptyFiles.size() == 1 && r.emptyFiles.get(0).endsWith("empty.webp"), "empty");
        check(r.mismatches.size() == 2, "mismatches " + r.mismatches.size());   // fake.webp and img.xml
        check(r.dupGroups == 1 && r.dupRedundantFiles == 3, "dups g=" + r.dupGroups + " r=" + r.dupRedundantFiles);
        check(r.hasDescription && r.descriptionRoot.equals("HwTheme") && !r.descriptionStrict, "description");
        check(r.descriptionFields.get("title").equals("t" + new String(Character.toChars(0x1F5A4)) + "x"), "surrogate pair title");
        byte[] th = a.readBytes(a.get("pkg.one/night/theme.xml"), 1000);
        check(new String(th, StandardCharsets.UTF_8).equals("<resources/>"), "nested read");
        check(a.readBytes(a.get("pkg.one/night/res/a.png"), 4).length == 4, "read limit");
        boolean threw = false;
        try { a.readBytes(a.get("wallpaper"), 10); } catch (IOException e) { threw = true; }
        check(threw, "folder read must fail");
        File cache = new File(tmpDir, "cache");
        String[] left = cache.list();
        check(left == null || left.length == 0, "temp copies must be removed");

        // not a zip
        File bad = new File(tmpDir, "bad.hnt");
        Files.write(bad.toPath(), new byte[]{1, 2, 3, 4, 5, 6});
        threw = false;
        try { ThemeArchive.open(bad, cache); } catch (IOException e) { threw = e.getMessage().startsWith("NOT_ZIP"); }
        check(threw, "non-zip must be rejected with NOT_ZIP");
    }

    public static void main(String[] args) throws Exception {
        File d = Files.createTempDirectory("s18test").toFile();
        run(d);
        System.out.println("SelfTest OK");
    }
}
