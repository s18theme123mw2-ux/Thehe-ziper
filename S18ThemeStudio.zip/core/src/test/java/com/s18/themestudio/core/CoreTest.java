package com.s18.themestudio.core;

import java.io.File;
import java.nio.file.Files;
import org.junit.jupiter.api.Test;

class CoreTest {
    @Test
    void engineSelfTest() throws Exception {
        File d = Files.createTempDirectory("s18test").toFile();
        SelfTest.run(d);
    }
}
