package com.s18.themestudio.core;

/** Detects the real type of a file from its first bytes. */
public final class Sniffer {
    private Sniffer() {}

    public static NodeKind sniff(byte[] h, int n) {
        if (n <= 0) return NodeKind.EMPTY;
        if (n >= 4 && h[0] == 'P' && h[1] == 'K'
                && ((h[2] == 3 && h[3] == 4) || (h[2] == 5 && h[3] == 6))) return NodeKind.ZIP;
        if (n >= 8 && (h[0] & 0xff) == 0x89 && h[1] == 'P' && h[2] == 'N' && h[3] == 'G'
                && h[4] == 0x0D && h[5] == 0x0A && h[6] == 0x1A && h[7] == 0x0A) return NodeKind.PNG;
        if (n >= 3 && (h[0] & 0xff) == 0xFF && (h[1] & 0xff) == 0xD8 && (h[2] & 0xff) == 0xFF) return NodeKind.JPEG;
        if (n >= 12 && h[0] == 'R' && h[1] == 'I' && h[2] == 'F' && h[3] == 'F'
                && h[8] == 'W' && h[9] == 'E' && h[10] == 'B' && h[11] == 'P') return NodeKind.WEBP;
        if (n >= 4 && h[0] == 3 && h[1] == 0 && h[2] == 8 && h[3] == 0) return NodeKind.AXML;
        if (n >= 4 && ((h[0] == 0 && h[1] == 1 && h[2] == 0 && h[3] == 0)
                || (h[0] == 't' && h[1] == 'r' && h[2] == 'u' && h[3] == 'e')
                || (h[0] == 'O' && h[1] == 'T' && h[2] == 'T' && h[3] == 'O')
                || (h[0] == 't' && h[1] == 't' && h[2] == 'c' && h[3] == 'f'))) return NodeKind.FONT;
        int i = 0;
        if (n >= 3 && (h[0] & 0xff) == 0xEF && (h[1] & 0xff) == 0xBB && (h[2] & 0xff) == 0xBF) i = 3;
        while (i < n && (h[i] == ' ' || h[i] == '\t' || h[i] == '\r' || h[i] == '\n')) i++;
        if (i < n && h[i] == '<') return NodeKind.XML;
        return NodeKind.BINARY;
    }
}
