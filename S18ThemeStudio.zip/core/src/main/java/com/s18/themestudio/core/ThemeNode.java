package com.s18.themestudio.core;

import java.util.List;

/** One entry in the virtual tree (outer archive entries and entries of nested archives). */
public final class ThemeNode {
    public final String name;
    public final String path;         // virtual path, '/' separated; nested archives behave like folders
    public final String parentPath;   // "" for top level
    public final boolean isDirectory; // a real or synthesized folder
    public final boolean isArchive;   // a ZIP that was expanded; it also acts as a folder
    public final long size;
    public final long compressedSize;
    public final int method;          // ZipEntry.STORED (0) / DEFLATED (8); -1 for folders
    public final long crc;
    public final NodeKind kind;
    public final String declaredExt;  // lowercase extension from the name, "" if none
    final List<String> chain;         // entry names to reach the bytes; null for folders

    ThemeNode(String name, String path, String parentPath, boolean isDirectory, boolean isArchive,
              long size, long compressedSize, int method, long crc, NodeKind kind,
              String declaredExt, List<String> chain) {
        this.name = name; this.path = path; this.parentPath = parentPath;
        this.isDirectory = isDirectory; this.isArchive = isArchive;
        this.size = size; this.compressedSize = compressedSize; this.method = method;
        this.crc = crc; this.kind = kind; this.declaredExt = declaredExt; this.chain = chain;
    }

    /** True when the node can be opened as a folder in the tree. */
    public boolean isContainer() { return isDirectory || isArchive; }
}
