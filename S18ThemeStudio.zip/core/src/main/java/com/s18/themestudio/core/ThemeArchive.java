package com.s18.themestudio.core;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

/**
 * Opens a theme package (HNT / HWT). Both are ZIP files whose entries are often ZIP files
 * themselves. The package is only read, never modified. Nested archives are listed through
 * temporary copies in cacheDir.
 */
public final class ThemeArchive {
    public static final int MAX_DEPTH = 4;

    private final File file;
    private final File cacheDir;
    private final Map<String, ThemeNode> nodes = new LinkedHashMap<String, ThemeNode>();
    private final Map<String, List<ThemeNode>> kids = new HashMap<String, List<ThemeNode>>();
    private final ThemeReport report = new ThemeReport();
    private int tmpCounter = 0;

    private ThemeArchive(File file, File cacheDir) {
        this.file = file;
        this.cacheDir = cacheDir;
    }

    public ThemeReport getReport() { return report; }

    public ThemeNode get(String path) { return nodes.get(path); }

    public int nodeCount() { return nodes.size(); }

    public List<ThemeNode> allNodes() { return new ArrayList<ThemeNode>(nodes.values()); }

    /** Children of a folder (or expanded archive); folders first, then by name. "" is the root. */
    public List<ThemeNode> children(String dirPath) {
        List<ThemeNode> l = kids.get(dirPath);
        if (l == null) return Collections.<ThemeNode>emptyList();
        List<ThemeNode> out = new ArrayList<ThemeNode>(l);
        Collections.sort(out, new Comparator<ThemeNode>() {
            @Override public int compare(ThemeNode a, ThemeNode b) {
                if (a.isContainer() != b.isContainer()) return a.isContainer() ? -1 : 1;
                return a.name.compareToIgnoreCase(b.name);
            }
        });
        return out;
    }

    /** Fails with an explanatory IOException when the file is not a ZIP package. */
    public static ThemeArchive open(File file, File cacheDir) throws IOException {
        byte[] head = new byte[16];
        int n;
        InputStream in = new java.io.FileInputStream(file);
        try { n = readFully(in, head); } finally { in.close(); }
        if (Sniffer.sniff(head, n) != NodeKind.ZIP) {
            StringBuilder hex = new StringBuilder();
            for (int i = 0; i < n; i++) hex.append(String.format("%02x", head[i] & 0xff));
            throw new IOException("NOT_ZIP: first bytes = " + hex);
        }
        if (!cacheDir.isDirectory() && !cacheDir.mkdirs()) throw new IOException("cannot create cache dir");
        ThemeArchive a = new ThemeArchive(file, cacheDir);
        a.report.outerSize = file.length();
        ZipFile zf = new ZipFile(file);
        try {
            a.scan(zf, new ArrayList<String>(), "", 0);
        } finally {
            zf.close();
        }
        a.finish();
        return a;
    }

    // ---------------------------------------------------------------- scanning

    private void scan(ZipFile zf, List<String> prefix, String base, int depth) throws IOException {
        int files = 0, stored = 0, deflated = 0, folders = 0;
        Enumeration<? extends ZipEntry> en = zf.entries();
        byte[] head = new byte[16];
        while (en.hasMoreElements()) {
            ZipEntry e = en.nextElement();
            String name = e.getName().replace('\\', '/');
            while (name.startsWith("/")) name = name.substring(1);
            boolean isDir = e.isDirectory();
            String rel = isDir ? name.substring(0, Math.max(0, name.length() - 1)) : name;
            if (rel.isEmpty() || hasDotDot(rel)) {
                report.warnings.add("skipped suspicious entry name: " + e.getName());
                continue;
            }
            String full = base.isEmpty() ? rel : base + "/" + rel;
            ensureParents(full);
            if (isDir) {
                folders++;
                if (!nodes.containsKey(full)) addNode(dirNode(full));
                continue;
            }
            files++;
            if (e.getMethod() == ZipEntry.STORED) stored++; else deflated++;
            NodeKind kind;
            int n = 0;
            if (e.getSize() == 0) {
                kind = NodeKind.EMPTY;
            } else {
                try {
                    InputStream in = zf.getInputStream(e);
                    try { n = readFully(in, head); } finally { in.close(); }
                    kind = Sniffer.sniff(head, n);
                } catch (IOException ex) {
                    kind = NodeKind.BINARY;
                    report.warnings.add("cannot read: " + full + " (" + ex.getMessage() + ")");
                }
            }
            List<String> chain = new ArrayList<String>(prefix);
            chain.add(e.getName());
            String nm = full.substring(full.lastIndexOf('/') + 1);
            boolean expanded = false;
            ThemeNode node = new ThemeNode(nm, full, parentOf(full), false, false, e.getSize(),
                    e.getCompressedSize(), e.getMethod(), e.getCrc(), kind, extOf(nm), chain);
            if (kind == NodeKind.ZIP && depth < MAX_DEPTH) {
                File tmp = newTmp();
                try {
                    copyEntry(zf, e, tmp);
                    ZipFile inner = new ZipFile(tmp);
                    try {
                        node = new ThemeNode(nm, full, parentOf(full), false, true, e.getSize(),
                                e.getCompressedSize(), e.getMethod(), e.getCrc(), kind, extOf(nm), chain);
                        addNode(node);
                        expanded = true;
                        report.archiveCount++;
                        if (depth + 1 > report.maxDepth) report.maxDepth = depth + 1;
                        scan(inner, chain, full, depth + 1);
                    } finally {
                        inner.close();
                    }
                } catch (IOException ex) {
                    report.warnings.add("cannot open nested archive: " + full + " (" + ex.getMessage() + ")");
                } finally {
                    tmp.delete();
                }
            }
            if (!expanded) addNode(node);
        }
        report.archives.add(new ArchiveInfo(base, files, stored, deflated, folders));
    }

    private void finish() {
        Map<String, List<ThemeNode>> groups = new HashMap<String, List<ThemeNode>>();
        for (ThemeNode nd : nodes.values()) {
            if (nd.isDirectory) continue;
            if (nd.isArchive) {
                // archive entries count as folders in the tree, keep them out of file stats
                continue;
            }
            report.totalFiles++;
            report.totalUncompressed += Math.max(0, nd.size);
            Integer c = report.kindCounts.get(nd.kind);
            report.kindCounts.put(nd.kind, c == null ? 1 : c + 1);
            if (nd.name.toLowerCase(Locale.ROOT).endsWith(".9.png")) report.ninePatchCount++;
            NodeKind expected = expectedKind(nd.declaredExt);
            if (expected != null) {
                if (nd.kind == NodeKind.EMPTY) report.emptyFiles.add(nd.path);
                else if (nd.kind != expected)
                    report.mismatches.add(new String[]{nd.path, nd.declaredExt, nd.kind.name()});
            }
            if (nd.size > 0) {
                String key = nd.crc + ":" + nd.size;
                List<ThemeNode> g = groups.get(key);
                if (g == null) { g = new ArrayList<ThemeNode>(); groups.put(key, g); }
                g.add(nd);
            }
        }
        for (List<ThemeNode> g : groups.values()) {
            if (g.size() > 1) {
                report.dupGroups++;
                report.dupRedundantFiles += g.size() - 1;
                report.dupWastedBytes += (long) (g.size() - 1) * g.get(0).size;
            }
        }
        ThemeNode d = nodes.get("description.xml");
        if (d != null && !d.isContainer()) {
            try {
                DescriptionParser.Result r = DescriptionParser.parse(readBytes(d, 512 * 1024));
                report.hasDescription = true;
                report.descriptionRoot = r.rootTag;
                report.descriptionStrict = r.strictXml;
                report.descriptionFields.putAll(r.fields);
            } catch (IOException ex) {
                report.warnings.add("cannot read description.xml: " + ex.getMessage());
            }
        }
    }

    private static NodeKind expectedKind(String ext) {
        if (ext.equals("png")) return NodeKind.PNG;
        if (ext.equals("jpg") || ext.equals("jpeg")) return NodeKind.JPEG;
        if (ext.equals("webp")) return NodeKind.WEBP;
        if (ext.equals("xml")) return NodeKind.XML;
        return null;
    }

    // ---------------------------------------------------------------- reading

    /**
     * Reads up to maxBytes of the entry's content (decompressed). Folders cannot be read.
     * Nested entries are read through a temporary copy of each archive on the way.
     */
    public byte[] readBytes(ThemeNode node, long maxBytes) throws IOException {
        if (node.chain == null) throw new IOException("a folder has no content");
        return readChain(file, node.chain, 0, maxBytes, new ArrayList<File>());
    }

    private byte[] readChain(File zipFile, List<String> chain, int idx, long max, List<File> tmps)
            throws IOException {
        ZipFile zf = new ZipFile(zipFile);
        File tmp = null;
        try {
            ZipEntry e = zf.getEntry(chain.get(idx));
            if (e == null) throw new IOException("entry not found: " + chain.get(idx));
            if (idx == chain.size() - 1) {
                InputStream in = zf.getInputStream(e);
                try {
                    ByteArrayOutputStream out = new ByteArrayOutputStream();
                    byte[] buf = new byte[16 * 1024];
                    long total = 0;
                    int r;
                    while (total < max && (r = in.read(buf, 0, (int) Math.min(buf.length, max - total))) > 0) {
                        out.write(buf, 0, r);
                        total += r;
                    }
                    return out.toByteArray();
                } finally {
                    in.close();
                }
            }
            tmp = newTmp();
            copyEntry(zf, e, tmp);
            return readChain(tmp, chain, idx + 1, max, tmps);
        } finally {
            zf.close();
            if (tmp != null) tmp.delete();
        }
    }

    // ---------------------------------------------------------------- helpers

    private File newTmp() { return new File(cacheDir, "n" + (tmpCounter++) + "_" + System.nanoTime() + ".zip"); }

    private static void copyEntry(ZipFile zf, ZipEntry e, File dest) throws IOException {
        InputStream in = zf.getInputStream(e);
        try {
            OutputStream out = new FileOutputStream(dest);
            try {
                byte[] buf = new byte[64 * 1024];
                int r;
                while ((r = in.read(buf)) > 0) out.write(buf, 0, r);
            } finally {
                out.close();
            }
        } finally {
            in.close();
        }
    }

    private void ensureParents(String full) {
        int idx = full.indexOf('/');
        while (idx >= 0) {
            String p = full.substring(0, idx);
            if (!nodes.containsKey(p)) addNode(dirNode(p));
            idx = full.indexOf('/', idx + 1);
        }
    }

    private ThemeNode dirNode(String path) {
        String nm = path.substring(path.lastIndexOf('/') + 1);
        return new ThemeNode(nm, path, parentOf(path), true, false, 0, 0, -1, 0, NodeKind.DIR, "", null);
    }

    private void addNode(ThemeNode n) {
        nodes.put(n.path, n);
        List<ThemeNode> l = kids.get(n.parentPath);
        if (l == null) { l = new ArrayList<ThemeNode>(); kids.put(n.parentPath, l); }
        // replace an earlier synthesized folder with the same path
        for (int i = 0; i < l.size(); i++) if (l.get(i).path.equals(n.path)) { l.set(i, n); return; }
        l.add(n);
    }

    private static String parentOf(String path) {
        int i = path.lastIndexOf('/');
        return i < 0 ? "" : path.substring(0, i);
    }

    private static String extOf(String name) {
        int i = name.lastIndexOf('.');
        return i <= 0 || i == name.length() - 1 ? "" : name.substring(i + 1).toLowerCase(Locale.ROOT);
    }

    private static boolean hasDotDot(String rel) {
        for (String s : rel.split("/")) if (s.equals("..")) return true;
        return false;
    }

    static int readFully(InputStream in, byte[] buf) throws IOException {
        int total = 0, r;
        while (total < buf.length && (r = in.read(buf, total, buf.length - total)) > 0) total += r;
        return total;
    }
}
