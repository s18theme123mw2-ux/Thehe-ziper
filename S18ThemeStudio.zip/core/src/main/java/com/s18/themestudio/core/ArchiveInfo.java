package com.s18.themestudio.core;

/** Per-archive facts needed later to rebuild an equivalent archive. */
public final class ArchiveInfo {
    public final String path;      // "" for the outer file
    public final int fileEntries;
    public final int storedEntries;
    public final int deflatedEntries;
    public final int folderEntries;
    public final boolean hasFolderEntries;

    ArchiveInfo(String path, int fileEntries, int storedEntries, int deflatedEntries, int folderEntries) {
        this.path = path; this.fileEntries = fileEntries; this.storedEntries = storedEntries;
        this.deflatedEntries = deflatedEntries; this.folderEntries = folderEntries;
        this.hasFolderEntries = folderEntries > 0;
    }
}
