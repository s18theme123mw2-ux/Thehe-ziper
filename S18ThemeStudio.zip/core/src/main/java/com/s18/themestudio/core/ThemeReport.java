package com.s18.themestudio.core;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Facts measured from the real archive. Nothing here is guessed. */
public final class ThemeReport {
    public long outerSize;
    public int totalFiles;
    public long totalUncompressed;
    public int archiveCount;                 // nested archives (not counting the outer file)
    public int maxDepth;                     // 0 = no nested archive
    public final Map<NodeKind, Integer> kindCounts = new LinkedHashMap<NodeKind, Integer>();
    public final List<String[]> mismatches = new ArrayList<String[]>(); // {path, declaredExt, realKind}
    public final List<String> emptyFiles = new ArrayList<String>();
    public int dupGroups;
    public int dupRedundantFiles;
    public long dupWastedBytes;
    public int ninePatchCount;
    public final List<ArchiveInfo> archives = new ArrayList<ArchiveInfo>();
    public final List<String> warnings = new ArrayList<String>();
    public String descriptionRoot = "";
    public boolean descriptionStrict;
    public final Map<String, String> descriptionFields = new LinkedHashMap<String, String>();
    public boolean hasDescription;
}
