package com.s18.themestudio.core;

import java.io.File;
import java.util.Map;

/** Command-line check: java -cp ... com.s18.themestudio.core.Cli theme.hnt [cacheDir] */
public final class Cli {
    public static void main(String[] a) throws Exception {
        File cache = new File(a.length > 1 ? a[1] : System.getProperty("java.io.tmpdir"), "s18cache");
        long t0 = System.currentTimeMillis();
        ThemeArchive ar = ThemeArchive.open(new File(a[0]), cache);
        ThemeReport r = ar.getReport();
        System.out.println("open ms: " + (System.currentTimeMillis() - t0));
        System.out.println("nodes: " + ar.nodeCount() + "  files: " + r.totalFiles
                + "  uncompressed: " + r.totalUncompressed + "  nested archives: " + r.archiveCount
                + "  maxDepth: " + r.maxDepth);
        System.out.println("kinds: " + r.kindCounts);
        System.out.println("nine-patch: " + r.ninePatchCount + "  empty: " + r.emptyFiles.size()
                + "  mismatches: " + r.mismatches.size());
        System.out.println("dups: groups=" + r.dupGroups + " redundant=" + r.dupRedundantFiles
                + " wastedBytes=" + r.dupWastedBytes);
        System.out.println("description: root=" + r.descriptionRoot + " strict=" + r.descriptionStrict);
        for (Map.Entry<String, String> e : r.descriptionFields.entrySet()) {
            String v = e.getValue();
            System.out.println("  " + e.getKey() + " = " + (v.length() > 60 ? v.substring(0, 60) + "..." : v)
                    .replace('\n', ' '));
        }
        System.out.println("warnings: " + r.warnings);
        System.out.println("root children: " + ar.children("").size());
        ThemeNode lm = ar.get("unlock/lockscreen/manifest.xml");
        if (lm != null) System.out.println("read manifest bytes: " + ar.readBytes(lm, 1 << 20).length);
        ThemeNode nested = ar.get("com.hihonor.android.launcher/night/theme.xml");
        if (nested != null) System.out.println("read nested theme.xml bytes: " + ar.readBytes(nested, 1 << 20).length);
    }
}
