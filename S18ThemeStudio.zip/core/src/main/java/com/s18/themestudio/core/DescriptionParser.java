package com.s18.themestudio.core;

import java.io.ByteArrayInputStream;
import java.nio.charset.StandardCharsets;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.xml.XMLConstants;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;

/**
 * Reads description.xml. Real themes are not always valid XML (e.g. emoji written as two
 * separate surrogate character references), so a strict parse is tried first and a tolerant
 * tag reader is used when it fails.
 */
public final class DescriptionParser {
    private DescriptionParser() {}

    public static final class Result {
        public String rootTag = "";
        public final Map<String, String> fields = new LinkedHashMap<String, String>();
        public boolean strictXml;
    }

    public static Result parse(byte[] data) {
        String text = new String(data, StandardCharsets.UTF_8);
        if (text.length() > 0 && text.charAt(0) == '﻿') text = text.substring(1);
        Result r = new Result();
        try {
            DocumentBuilderFactory f = DocumentBuilderFactory.newInstance();
            f.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true);
            f.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
            f.setExpandEntityReferences(false);
            DocumentBuilder b = f.newDocumentBuilder();
            b.setErrorHandler(null);
            b.setErrorHandler(new org.xml.sax.helpers.DefaultHandler() {
                @Override public void error(org.xml.sax.SAXParseException e) throws org.xml.sax.SAXException { throw e; }
                @Override public void fatalError(org.xml.sax.SAXParseException e) throws org.xml.sax.SAXException { throw e; }
            });
            Document d = b.parse(new ByteArrayInputStream(text.getBytes(StandardCharsets.UTF_8)));
            Element root = d.getDocumentElement();
            r.rootTag = root.getTagName();
            for (Node c = root.getFirstChild(); c != null; c = c.getNextSibling()) {
                if (c.getNodeType() == Node.ELEMENT_NODE) {
                    r.fields.put(c.getNodeName(), c.getTextContent().trim());
                }
            }
            r.strictXml = true;
            return r;
        } catch (Throwable t) {
            r.rootTag = ""; r.fields.clear(); r.strictXml = false;
        }
        Matcher rm = Pattern.compile("<([A-Za-z_][\\w.-]*)[\\s>]").matcher(text);
        if (!rm.find()) return r;
        r.rootTag = rm.group(1);
        String rest = text.substring(rm.end() - 1);
        Matcher m = Pattern.compile("<([A-Za-z_][\\w.-]*)>([\\s\\S]*?)</\\1>").matcher(rest);
        while (m.find()) r.fields.put(m.group(1), decode(m.group(2)).trim());
        return r;
    }

    static String decode(String s) {
        Matcher m = Pattern.compile("&(#x[0-9a-fA-F]+|#[0-9]+|amp|lt|gt|quot|apos);").matcher(s);
        StringBuilder out = new StringBuilder();
        int last = 0;
        while (m.find()) {
            out.append(s, last, m.start());
            String g = m.group(1);
            if (g.startsWith("#x")) out.append((char) Integer.parseInt(g.substring(2), 16));
            else if (g.startsWith("#")) out.append((char) Integer.parseInt(g.substring(1)));
            else if (g.equals("amp")) out.append('&');
            else if (g.equals("lt")) out.append('<');
            else if (g.equals("gt")) out.append('>');
            else if (g.equals("quot")) out.append('"');
            else out.append('\'');
            last = m.end();
        }
        out.append(s, last, s.length());
        return out.toString();
    }
}
