package com.s18.themestudio.core;

/** Real content type of an entry, detected from its bytes (never from its file name). */
public enum NodeKind {
    DIR, ZIP, PNG, JPEG, WEBP, XML, AXML, FONT, EMPTY, BINARY
}
