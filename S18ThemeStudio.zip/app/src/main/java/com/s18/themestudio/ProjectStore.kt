package com.s18.themestudio

import android.content.ContentResolver
import android.net.Uri
import android.provider.OpenableColumns
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.security.DigestInputStream
import java.security.MessageDigest
import java.util.UUID

data class Project(
    val id: String,
    val name: String,
    val ext: String,
    val sha256: String,
    val size: Long,
    val importedAt: Long,
)

/**
 * Local projects. Every import is copied into app-private storage and made read-only;
 * the file the user picked is never touched.
 */
class ProjectStore(private val root: File) {
    init {
        root.mkdirs()
    }

    fun list(): List<Project> {
        val dirs = root.listFiles() ?: return emptyList()
        return dirs.filter { it.isDirectory }
            .mapNotNull { readMeta(it) }
            .sortedByDescending { it.importedAt }
    }

    fun originalFile(p: Project): File = File(File(root, p.id), "original." + p.ext)

    fun cacheDir(p: Project): File = File(File(root, p.id), "cache")

    fun delete(p: Project) {
        File(root, p.id).deleteRecursively()
    }

    fun importFrom(resolver: ContentResolver, uri: Uri): Project {
        var name = "theme"
        resolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) {
                val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (i >= 0) c.getString(i)?.let { name = it }
            }
        }
        val dot = name.lastIndexOf('.')
        val rawExt = if (dot > 0 && dot < name.length - 1) name.substring(dot + 1).lowercase() else ""
        val ext = rawExt.filter { it.isLetterOrDigit() }.ifEmpty { "bin" }
        val id = UUID.randomUUID().toString()
        val dir = File(root, id)
        dir.mkdirs()
        try {
            val md = MessageDigest.getInstance("SHA-256")
            val part = File(dir, "original.part")
            var total = 0L
            val input = resolver.openInputStream(uri) ?: throw IOException("cannot open the selected file")
            input.use { raw ->
                DigestInputStream(raw, md).use { ins ->
                    part.outputStream().use { out -> total = ins.copyTo(out) }
                }
            }
            val target = File(dir, "original.$ext")
            if (!part.renameTo(target)) throw IOException("cannot store the file")
            target.setReadOnly()
            val sha = md.digest().joinToString("") { "%02x".format(it) }
            val p = Project(id, name, ext, sha, total, System.currentTimeMillis())
            writeMeta(dir, p)
            return p
        } catch (t: Throwable) {
            dir.deleteRecursively()
            throw t
        }
    }

    private fun writeMeta(dir: File, p: Project) {
        val o = JSONObject()
        o.put("id", p.id)
        o.put("name", p.name)
        o.put("ext", p.ext)
        o.put("sha256", p.sha256)
        o.put("size", p.size)
        o.put("importedAt", p.importedAt)
        File(dir, "project.json").writeText(o.toString(), Charsets.UTF_8)
    }

    private fun readMeta(dir: File): Project? {
        val f = File(dir, "project.json")
        if (!f.isFile) return null
        return try {
            val o = JSONObject(f.readText(Charsets.UTF_8))
            Project(
                o.getString("id"), o.getString("name"), o.getString("ext"),
                o.getString("sha256"), o.getLong("size"), o.getLong("importedAt"),
            )
        } catch (e: Exception) {
            null
        }
    }
}
