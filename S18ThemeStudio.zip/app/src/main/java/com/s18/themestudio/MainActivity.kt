package com.s18.themestudio

import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.Image
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.s18.themestudio.core.NodeKind
import com.s18.themestudio.core.ThemeArchive
import com.s18.themestudio.core.ThemeNode
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.Locale

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val store = ProjectStore(File(filesDir, "projects"))
        setContent {
            MaterialTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    App(store)
                }
            }
        }
    }
}

fun fmtSize(b: Long): String = when {
    b < 1024 -> "$b B"
    b < 1024 * 1024 -> String.format(Locale.US, "%.1f KB", b / 1024.0)
    else -> String.format(Locale.US, "%.1f MB", b / (1024.0 * 1024.0))
}

@Composable
fun App(store: ProjectStore) {
    var open by remember { mutableStateOf<Project?>(null) }
    val p = open
    if (p == null) {
        HomeScreen(store) { open = it }
    } else {
        ProjectScreen(store, p) { open = null }
    }
}

// ------------------------------------------------------------------ home

@Composable
fun HomeScreen(store: ProjectStore, onOpen: (Project) -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var projects by remember { mutableStateOf(store.list()) }
    var status by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    var toDelete by remember { mutableStateOf<Project?>(null) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) {
            busy = true
            status = ctx.getString(R.string.importing)
            scope.launch {
                val res = withContext(Dispatchers.IO) { runCatching { store.importFrom(ctx.contentResolver, uri) } }
                busy = false
                res.onSuccess {
                    status = ctx.getString(R.string.import_ok, it.name)
                    projects = store.list()
                }.onFailure {
                    status = ctx.getString(R.string.import_fail, it.message ?: it.javaClass.simpleName)
                }
            }
        }
    }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text(stringResource(R.string.app_name), style = MaterialTheme.typography.headlineSmall)
        Button(
            onClick = { picker.launch(arrayOf("*/*")) },
            enabled = !busy,
            modifier = Modifier.fillMaxWidth().padding(top = 12.dp),
        ) { Text(stringResource(R.string.import_theme)) }
        status?.let { Text(it, modifier = Modifier.padding(top = 8.dp)) }
        Text(
            stringResource(R.string.projects),
            style = MaterialTheme.typography.titleMedium,
            modifier = Modifier.padding(top = 16.dp, bottom = 8.dp),
        )
        if (projects.isEmpty()) {
            Text(stringResource(R.string.no_projects))
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(projects, key = { it.id }) { p ->
                    Card(Modifier.fillMaxWidth().clickable { onOpen(p) }) {
                        Row(Modifier.padding(12.dp), verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(p.name, style = MaterialTheme.typography.titleSmall)
                                Text(fmtSize(p.size) + "  •  " + p.sha256.take(12), fontSize = 12.sp)
                            }
                            TextButton(onClick = { toDelete = p }) { Text(stringResource(R.string.delete)) }
                        }
                    }
                }
            }
        }
    }

    val d = toDelete
    if (d != null) {
        AlertDialog(
            onDismissRequest = { toDelete = null },
            title = { Text(d.name) },
            text = { Text(stringResource(R.string.delete) + "?") },
            confirmButton = {
                TextButton(onClick = {
                    store.delete(d)
                    projects = store.list()
                    status = ctx.getString(R.string.deleted)
                    toDelete = null
                }) { Text(stringResource(R.string.delete)) }
            },
            dismissButton = { TextButton(onClick = { toDelete = null }) { Text(stringResource(R.string.back)) } },
        )
    }
}

// ------------------------------------------------------------------ project

sealed interface LoadState {
    object Loading : LoadState
    class Ready(val archive: ThemeArchive) : LoadState
    class Failed(val message: String) : LoadState
}

@Composable
fun ProjectScreen(store: ProjectStore, project: Project, onClose: () -> Unit) {
    val ctx = LocalContext.current
    var state by remember { mutableStateOf<LoadState>(LoadState.Loading) }
    var tab by remember { mutableIntStateOf(0) }
    var path by remember { mutableStateOf("") }
    var selected by remember { mutableStateOf<ThemeNode?>(null) }

    LaunchedEffect(project.id) {
        state = withContext(Dispatchers.IO) {
            try {
                LoadState.Ready(ThemeArchive.open(store.originalFile(project), store.cacheDir(project)))
            } catch (e: Throwable) {
                val m = e.message ?: e.javaClass.simpleName
                if (m.startsWith("NOT_ZIP")) {
                    LoadState.Failed(ctx.getString(R.string.not_zip, m.substringAfter("= ")))
                } else {
                    LoadState.Failed(ctx.getString(R.string.open_fail, m))
                }
            }
        }
    }

    BackHandler(enabled = true) {
        when {
            selected != null -> selected = null
            tab == 0 && path.isNotEmpty() -> path = path.substringBeforeLast('/', "")
            else -> onClose()
        }
    }

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp), verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
            TextButton(onClick = onClose) { Text(stringResource(R.string.back)) }
            Text(project.name, style = MaterialTheme.typography.titleSmall, maxLines = 1, modifier = Modifier.weight(1f))
        }
        when (val s = state) {
            is LoadState.Loading -> Text(stringResource(R.string.loading), modifier = Modifier.padding(16.dp))
            is LoadState.Failed -> Text(s.message, modifier = Modifier.padding(16.dp))
            is LoadState.Ready -> {
                TabRow(selectedTabIndex = tab) {
                    Tab(selected = tab == 0, onClick = { tab = 0 }, text = { Text(stringResource(R.string.tab_files)) })
                    Tab(selected = tab == 1, onClick = { tab = 1 }, text = { Text(stringResource(R.string.tab_report)) })
                }
                if (tab == 1) {
                    ReportTab(s.archive, project)
                } else {
                    val sel = selected
                    if (sel != null) {
                        FileViewer(s.archive, sel)
                    } else {
                        FilesTab(s.archive, path, onPath = { path = it }, onSelect = { selected = it })
                    }
                }
            }
        }
    }
}

@Composable
fun FilesTab(archive: ThemeArchive, path: String, onPath: (String) -> Unit, onSelect: (ThemeNode) -> Unit) {
    val children = remember(path) { archive.children(path) }
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp), verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
            if (path.isNotEmpty()) {
                TextButton(onClick = { onPath(path.substringBeforeLast('/', "")) }) { Text(stringResource(R.string.up)) }
            }
            Text("/" + path, fontFamily = FontFamily.Monospace, fontSize = 12.sp, modifier = Modifier.weight(1f))
        }
        HorizontalDivider()
        if (children.isEmpty()) {
            Text(stringResource(R.string.empty_folder), modifier = Modifier.padding(16.dp))
        } else {
            LazyColumn(Modifier.fillMaxSize()) {
                items(children, key = { it.path }) { n ->
                    Column(
                        Modifier.fillMaxWidth()
                            .clickable { if (n.isContainer) onPath(n.path) else onSelect(n) }
                            .padding(horizontal = 16.dp, vertical = 10.dp),
                    ) {
                        val tag = if (n.isArchive) "  [" + stringResource(R.string.archive_tag) + "]" else ""
                        Text((if (n.isContainer) "📁 " else "") + n.name + tag)
                        val sub = if (n.isContainer) {
                            stringResource(R.string.folder_items, archive.children(n.path).size)
                        } else {
                            fmtSize(n.size) + "  •  " + n.kind.name
                        }
                        Text(sub, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    HorizontalDivider()
                }
            }
        }
    }
}

sealed interface Preview {
    object Loading : Preview
    class Txt(val text: String, val truncated: Boolean) : Preview
    class Img(val bitmap: ImageBitmap) : Preview
    class Msg(val text: String) : Preview
}

private fun mismatch(n: ThemeNode): Boolean {
    val expected = when (n.declaredExt) {
        "png" -> NodeKind.PNG
        "jpg", "jpeg" -> NodeKind.JPEG
        "webp" -> NodeKind.WEBP
        "xml" -> NodeKind.XML
        else -> null
    }
    return expected != null && n.kind != NodeKind.EMPTY && n.kind != expected
}

@Composable
fun FileViewer(archive: ThemeArchive, node: ThemeNode) {
    val ctx = LocalContext.current
    var preview by remember(node.path) { mutableStateOf<Preview>(Preview.Loading) }

    LaunchedEffect(node.path) {
        preview = withContext(Dispatchers.IO) {
            try {
                when (node.kind) {
                    NodeKind.PNG, NodeKind.JPEG, NodeKind.WEBP -> {
                        val bytes = archive.readBytes(node, 16L * 1024 * 1024)
                        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
                        var sample = 1
                        while (bounds.outWidth / sample > 2048 || bounds.outHeight / sample > 2048) sample *= 2
                        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
                        val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size, opts)
                        if (bmp == null) Preview.Msg(ctx.getString(R.string.decode_fail)) else Preview.Img(bmp.asImageBitmap())
                    }
                    NodeKind.XML -> {
                        val cap = 512L * 1024
                        val bytes = archive.readBytes(node, cap)
                        Preview.Txt(String(bytes, Charsets.UTF_8), node.size > cap)
                    }
                    NodeKind.AXML -> Preview.Msg(ctx.getString(R.string.binary_xml))
                    NodeKind.EMPTY -> Preview.Msg(ctx.getString(R.string.empty_file))
                    else -> Preview.Msg(ctx.getString(R.string.no_preview))
                }
            } catch (e: Throwable) {
                Preview.Msg(ctx.getString(R.string.read_fail, e.message ?: e.javaClass.simpleName))
            }
        }
    }

    Column(Modifier.fillMaxSize().padding(12.dp)) {
        Text(node.name, style = MaterialTheme.typography.titleSmall)
        Text(node.path, fontFamily = FontFamily.Monospace, fontSize = 11.sp)
        Text(stringResource(R.string.size_label, fmtSize(node.size)) + "  •  " +
            stringResource(R.string.real_type, node.kind.name), fontSize = 12.sp)
        if (node.declaredExt.isNotEmpty()) {
            Text(stringResource(R.string.declared_type, node.declaredExt), fontSize = 12.sp)
        }
        if (mismatch(node)) {
            Text(stringResource(R.string.type_mismatch), color = MaterialTheme.colorScheme.error, fontSize = 12.sp)
        }
        HorizontalDivider(Modifier.padding(vertical = 8.dp))
        when (val p = preview) {
            is Preview.Loading -> Text(stringResource(R.string.loading))
            is Preview.Msg -> Text(p.text)
            is Preview.Img -> Box(Modifier.fillMaxSize().background(Color(0xFF8A8A8A))) {
                Image(bitmap = p.bitmap, contentDescription = node.name, contentScale = ContentScale.Fit, modifier = Modifier.fillMaxSize())
            }
            is Preview.Txt -> Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
                if (p.truncated) Text(stringResource(R.string.truncated, "512 KB"), fontSize = 12.sp)
                SelectionContainer {
                    Text(p.text, fontFamily = FontFamily.Monospace, fontSize = 12.sp)
                }
            }
        }
    }
}

@Composable
fun ReportTab(archive: ThemeArchive, project: Project) {
    val r = archive.report
    val none = stringResource(R.string.r_none)
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        Section(stringResource(R.string.r_overview))
        Text(stringResource(R.string.r_files, r.totalFiles, r.archiveCount))
        Text(stringResource(R.string.r_size, fmtSize(r.outerSize), fmtSize(r.totalUncompressed)))
        Text(stringResource(R.string.r_sha, project.sha256), fontFamily = FontFamily.Monospace, fontSize = 11.sp)

        Section(if (r.hasDescription) stringResource(R.string.r_description, r.descriptionRoot) else stringResource(R.string.r_no_description))
        if (r.hasDescription && !r.descriptionStrict) Text(stringResource(R.string.r_description_lenient), fontSize = 12.sp)
        for ((k, v) in r.descriptionFields) {
            Text(k + " = " + (if (v.length > 300) v.take(300) + "…" else v), fontSize = 12.sp)
        }

        Section(stringResource(R.string.r_kinds))
        for ((k, v) in r.kindCounts) Text(k.name + ": " + v)

        Section(stringResource(R.string.r_special))
        Text(stringResource(R.string.r_ninepatch, r.ninePatchCount))
        Text(stringResource(R.string.r_empty, r.emptyFiles.size))
        Text(stringResource(R.string.r_mismatch, r.mismatches.size))
        for (m in r.mismatches.take(30)) {
            Text(m[0] + "  (" + m[1] + " → " + m[2] + ")", fontFamily = FontFamily.Monospace, fontSize = 11.sp)
        }
        if (r.mismatches.size > 30) Text("…")
        for (e in r.emptyFiles.take(30)) Text(e + "  (0 B)", fontFamily = FontFamily.Monospace, fontSize = 11.sp)
        Text(stringResource(R.string.r_dups, r.dupGroups, r.dupRedundantFiles, fmtSize(r.dupWastedBytes)))
        Text(stringResource(R.string.r_dups_note), fontSize = 12.sp)

        Section(stringResource(R.string.r_warnings))
        if (r.warnings.isEmpty()) Text(none) else for (w in r.warnings.take(50)) Text(w, fontSize = 12.sp)

        Section(stringResource(R.string.r_archives))
        val outerLabel = stringResource(R.string.r_outer)
        for (a in r.archives.filter { it.path.isEmpty() || it.storedEntries > 0 }) {
            Text(
                stringResource(R.string.r_archive_line, if (a.path.isEmpty()) outerLabel else a.path, a.fileEntries, a.storedEntries, a.deflatedEntries),
                fontSize = 12.sp,
            )
        }
    }
}

@Composable
private fun Section(title: String) {
    Text(title, style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(top = 16.dp, bottom = 4.dp))
}
